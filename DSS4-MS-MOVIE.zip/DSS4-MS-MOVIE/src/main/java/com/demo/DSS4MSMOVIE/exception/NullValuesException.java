package com.demo.DSS4MSMOVIE.exception;

public class NullValuesException extends RuntimeException{
    public NullValuesException(String message){
       super(message);
    }
}
