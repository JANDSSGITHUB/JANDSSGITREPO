package com.demo.DSS4MSMOVIE.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActorRequestModel {
    private String firstName;
    private String lastName;
    private char gender;
    private int age;
}
