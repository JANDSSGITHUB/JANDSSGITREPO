package com.dss.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegistrationRequestModel {
    private String password;
    private String username;

}
