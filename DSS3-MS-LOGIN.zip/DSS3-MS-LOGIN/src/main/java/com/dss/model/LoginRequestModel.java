package com.dss.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequestModel {
    private String emailId;
    private String password;
}
