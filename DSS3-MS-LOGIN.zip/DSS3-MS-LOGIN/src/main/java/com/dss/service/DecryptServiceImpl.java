package com.dss.service;


import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.dss.exception.NoRegisteredAccountException;
import com.dss.model.User;
import com.dss.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import static com.dss.util.SecurityConstants.EXPIRATION_TIME;
import static com.dss.util.SecurityConstants.SECRET;

@Service
public class DecryptServiceImpl implements DecryptService {

    @Autowired
    AdminRepository registrationRepository;

    public User decryptPass(User user){
        String hashedPassword = getDecryptedPass(user.getPassword());
        user.setPassword(hashedPassword);
        return user;
    }

    public User validateUser(String emailId, String password){

            String hashedPassword = getDecryptedPass(password);
            User user = findByEmailIdAndPassword(emailId,hashedPassword);
            if(user!=null){
                String token = JWT.create()
                        .withExpiresAt(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                        .sign(Algorithm.HMAC512(SECRET.getBytes()));
                user.setToken(token);
                return user;
            }else throw new NoRegisteredAccountException("No Registered Account!");
    }

    public User findByEmailIdAndPassword(String username, String password){
        return registrationRepository.findByEmailIdAndPassword(username,password);
    }

    private String getDecryptedPass(String password){
        MessageDigest messageDigest;
        try {
            messageDigest = MessageDigest.getInstance("MD5");
            byte[] passwordInBytes = password.getBytes();
            messageDigest.update(passwordInBytes);
            byte[] resultByteArray = messageDigest.digest();
            StringBuilder stringBuilder = new StringBuilder();
            for(byte byteVar : resultByteArray) {
                String formattedString = String.format("%02x", byteVar);
                stringBuilder.append(formattedString);
            }
            return stringBuilder.toString();

        } catch (NoSuchAlgorithmException e) {
            System.out.println("No Such Algorithm....");
            throw new RuntimeException(e);
        }
    }
}
