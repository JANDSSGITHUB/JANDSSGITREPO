package com.dss.exception;

public class NullValuesException extends RuntimeException{
    public NullValuesException(String message){
       super(message);
    }
}
