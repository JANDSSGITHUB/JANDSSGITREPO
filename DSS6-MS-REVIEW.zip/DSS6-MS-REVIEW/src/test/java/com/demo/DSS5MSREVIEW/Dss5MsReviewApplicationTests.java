package com.demo.DSS5MSREVIEW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dss5MsReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
