package com.demo.DSS5MSREVIEW.exception;

public class NullValuesException extends RuntimeException{
    public NullValuesException(String message){
       super(message);
    }
}
