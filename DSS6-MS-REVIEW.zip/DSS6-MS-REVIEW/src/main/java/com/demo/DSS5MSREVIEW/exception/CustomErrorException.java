package com.demo.DSS5MSREVIEW.exception;

public class CustomErrorException extends RuntimeException{
    public CustomErrorException(String message){
        super(message);
    }
}
