package com.demo.DSS5MSREVIEW.service;


import com.demo.DSS5MSREVIEW.exception.CustomErrorException;
import com.demo.DSS5MSREVIEW.model.Movie;
import com.demo.DSS5MSREVIEW.model.Review;
import com.demo.DSS5MSREVIEW.model.ReviewRequestModel;
import com.demo.DSS5MSREVIEW.repository.MovieRepository;
import com.demo.DSS5MSREVIEW.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService{

    @Autowired
    ReviewRepository reviewRepository;

    @Autowired
    MovieRepository movieRepository;

    @Override
    public void save(ReviewRequestModel requestModel) {
        validate(requestModel);
        Review review = setValues(requestModel);
        reviewRepository.save(review);
    }

    @Override
    public ArrayList<Review> findAll() {

        List<Review> reviewList = reviewRepository.findAll();
        return new ArrayList<>(reviewList);
    }


    private void validate(ReviewRequestModel requestModel){
        if(requestModel.getDescription().isEmpty() || requestModel.getPostedDate() == null || requestModel.getRating() == 0){
            throw new CustomErrorException("Please fill up all the values");
        }
        Movie movie = findByMovieId(requestModel.getMovieId());
        if(movie==null){
            throw new CustomErrorException("Movie not found");
        }

    }
    private Review setValues(ReviewRequestModel requestModel){
        Movie movie = findByMovieId(requestModel.getMovieId());
         return new Review(requestModel.getDescription(),requestModel.getPostedDate(),requestModel.getRating(),movie);
    }
    private Movie findByMovieId(int movieId){
        return movieRepository.findByMovieId(movieId);
    }
}
